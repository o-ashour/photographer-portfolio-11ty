export { activate } from "./src/extension";
