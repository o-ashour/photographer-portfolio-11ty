module.exports = {
    extends: [
        "@enter-at/typescript-prettier"
    ],
    rules: {
        "class-methods-use-this": "off",
        "import/prefer-default-export": "off"
    },
}
