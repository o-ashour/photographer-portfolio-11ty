# Domestika 11ty

A minimal 11ty starting point.

## Getting Started

Install all dependencies using npm:

```
$ npm install
```

### To Develop

```
$ npm run dev
```

You can view the website at the given access URL:

```
$ light-server is listening at http://localhost:4000
```

The local url is configured in `.lightserverrc`

### To Build

```
npm run build
```
